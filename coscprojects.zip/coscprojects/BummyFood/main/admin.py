from django.contrib import admin

from main.models import UserReservation, Tables
# from .models import

# Register your models here.
admin.site.register(UserReservation)
admin.site.register(Tables)
